package com.phw.dao;


import com.phw.pojo.User;
import com.phw.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;




public class UserDAOTest {

    @Test
    public void getUserById() {
        SqlSession sqlSession = MybatisUtils.getSqlSession();

        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        User user = mapper.getUserById(3);
        System.out.println(user);

        sqlSession.close();
    }

}
