package com.phw.dao;



import com.phw.pojo.User;
import com.phw.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

public class UserMapperTest {

    @Test
    public void test() {
        SqlSession sqlSession = MybatisUtils.getSqlSession();
        //底层主要应用反射
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        mapper.updateUser(new User(5,"to","66666"));


        sqlSession.close();
    }
    /*mapper.deleteUser(5);*/

    /*mapper.addUser(new User(5,"hello","7879"));*/

    /*List<User> users = mapper.getUsers();
        for (User user : users) {
            System.out.println(user);
        }

        User userById = mapper.getUserById(3);
        System.out.println(userById);
        */
}
